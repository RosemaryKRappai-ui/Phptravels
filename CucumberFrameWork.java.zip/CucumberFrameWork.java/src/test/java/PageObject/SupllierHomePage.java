package PageObject;

public class SupllierHomePage {

}
