package PageObject;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class AgentHomePage {
	WebDriver driver;
	@FindBy(xpath = "//ul[@class='sidebar-menu list-items']//li[2]")
	WebElement myBooking;
	@FindBy(css = "ul[class='sidebar-menu list-items'] li[class='user_wallet ']")
	WebElement addFund;
	@FindBy(xpath = "//ul[@class='sidebar-menu list-items']//li[4]")
	WebElement myProfile;
	@FindBy(xpath = "//ul[@class='sidebar-menu list-items']//li[5]")
	WebElement logout;
	@FindBy(css = "div[class='header-right-action  pt-1 pe-2 multi_currency'] button")
	WebElement dropdowncurrency;
	@FindBy(xpath = "//ul[@class='dropdown-menu show']//li[7]")
	WebElement selectINR;
	
	public AgentHomePage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	public void setMybookig(){
		myBooking.click();
	}
	public void setAddFund(){
		addFund.click();
	}
	public void setmyProfile(){
		myProfile.click();
	}
	public void setLogout(){
		logout.click();
	}
	public void setcurrencydropdown() throws InterruptedException {
		Thread.sleep(2000);
		dropdowncurrency.click();
	}
	public void selectinr() {
		selectINR.click();
	}
	
	@FindBy(css = "a[title='flights']")
	WebElement Flight;
	@FindBy(css = "a[title='blog']")
	WebElement blog;
	@FindBy(css = "a[title='flights']")
	WebElement offers;
	@FindBy(css = "a[title='flights']")
	WebElement hotel;
}
