package StepDefinition;

import org.junit.Assert;
import org.openqa.selenium.chrome.ChromeDriver;

import PageObject.AdminLoginPage;
import PageObject.SupllierLoginPage;
import io.cucumber.java.en.*;

public class SupllierStepClass extends TestBase{

	@Given("Supllier launch the browser")
	public void supllier_launch_the_browser() {
		driver = new ChromeDriver();
		driver.manage().window().maximize();
	}

	@Given("Supllier enter the url {string}")
	public void supllier_enter_the_url(String url) throws InterruptedException {
		driver.get(url);
		Thread.sleep(1000);
	}

	@When("Supllier enter username {string} and password {string}")
	public void supllier_enter_username_and_password(String username, String passwords) {
		supllierlogon = new SupllierLoginPage(driver);
		supllierlogon.setUsernamePassword(username, passwords);
	}
	@When("Supllier click login button")
	public void supllier_click_login_button() {
		supllierlogon.setLoginButton();
	}
	@Then("launch the Supllier home page")
	public void launch_the_Supllier_home_page() throws InterruptedException {
		Thread.sleep(3000);
		Assert.assertTrue(driver.getPageSource().contains("Dashboard"));
	}
	@Then("close the Supllier browser")
	public void close_the_Supllier_browser() {
	    driver.quit();
	}
	@Then("Display error message")
	public void supllier_message_will_show() throws InterruptedException {
		Thread.sleep(2000);
		Assert.assertTrue(driver.getPageSource().contains("Invalid Login Credentials"));
	}
// ----------------------------------------------------------	
	@Then("launch the Supllier Dashboard")
	public void launch_the_Supllier_Dashboard() {
	    // Write code here that turns the phrase above into concrete actions
	    throw new io.cucumber.java.PendingException();
	}

	@Then("check the text {string}")
	public void check_the_text(String string) {
	    // Write code here that turns the phrase above into concrete actions
	    throw new io.cucumber.java.PendingException();
	}
// ----------------------------------------------------------
	@Then("check the text Revenue Breakdown")
	public void check_the_text_Revenue_Breakdown() {
	    // Write code here that turns the phrase above into concrete actions
	    throw new io.cucumber.java.PendingException();
	}
// ----------------------------------------------------------
	@When("Supplier click on Pending status")
	public void supplier_click_on_Pending_status() {
	    // Write code here that turns the phrase above into concrete actions
	    throw new io.cucumber.java.PendingException();
	}

	@Then("Launch the pending list")
	public void launch_the_pending_list() {
	    // Write code here that turns the phrase above into concrete actions
	    throw new io.cucumber.java.PendingException();
	}

	@Then("change the pending to confirmed status")
	public void change_the_pending_to_confirmed_status() {
	    // Write code here that turns the phrase above into concrete actions
	    throw new io.cucumber.java.PendingException();
	}

	@Then("check the status count in DashBoard")
	public void check_the_status_count_in_DashBoard() {
	    // Write code here that turns the phrase above into concrete actions
	    throw new io.cucumber.java.PendingException();
	}
// --------------------------------------------------------------------------------
	@When("Supllier click on Flight Link")
	public void supllier_click_on_Flight_Link() {
	    // Write code here that turns the phrase above into concrete actions
	    throw new io.cucumber.java.PendingException();
	}

	@Then("Supllier see launch the Flight page")
	public void supllier_see_launch_the_Flight_page() {
	    // Write code here that turns the phrase above into concrete actions
	    throw new io.cucumber.java.PendingException();
	}

	@Then("Supllier click on Tours Link")
	public void supllier_click_on_Tours_Link() {
	    // Write code here that turns the phrase above into concrete actions
	    throw new io.cucumber.java.PendingException();
	}

	@Then("Supllier see launch the Tours page")
	public void supllier_see_launch_the_Tours_page() {
	    // Write code here that turns the phrase above into concrete actions
	    throw new io.cucumber.java.PendingException();
	}

	@Then("Supllier  click on visa Link")
	public void supllier_click_on_visa_Link() {
	    // Write code here that turns the phrase above into concrete actions
	    throw new io.cucumber.java.PendingException();
	}

	@Then("Supllier see launch the visa page")
	public void supllier_see_launch_the_visa_page() {
	    // Write code here that turns the phrase above into concrete actions
	    throw new io.cucumber.java.PendingException();
	}

	@Then("click on Booking Link")
	public void click_on_Booking_Link() {
	    // Write code here that turns the phrase above into concrete actions
	    throw new io.cucumber.java.PendingException();
	}

	@Then("launch the Booking page")
	public void launch_the_Booking_page() {
	    // Write code here that turns the phrase above into concrete actions
	    throw new io.cucumber.java.PendingException();
	}



}
